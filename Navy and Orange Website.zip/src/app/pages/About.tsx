import { Link } from "react-router";
import { ArrowRight, CheckCircle2, Award, Shield, Users, Clock } from "lucide-react";

const NAV = "#0B1C36";
const ORANGE = "#F06A1A";

const VALUES = [
  { icon: <Award size={24} />, title: "Quality Craftsmanship", desc: "Every job is completed to the standard we'd want in our own homes. No cutting corners, no rushing." },
  { icon: <Shield size={24} />, title: "Total Transparency", desc: "You receive a detailed written quote before any work begins. No hidden costs, no surprises on completion." },
  { icon: <Users size={24} />, title: "One Team", desc: "We don't sub-contract. Every trade on your project is employed by us, so quality control is always in our hands." },
  { icon: <Clock size={24} />, title: "Respect for Your Time", desc: "We keep to agreed schedules and keep you informed throughout. Your project won't be left dormant." },
];

const TEAM = [
  { name: "Danny Mitchell", role: "Managing Director & Groundworks Lead", img: "https://images.unsplash.com/photo-1558227691-41ea78d1f631?w=400&h=500&fit=crop&auto=format" },
  { name: "Mark Ashford", role: "Site Foreman & Brickwork Specialist", img: "https://images.unsplash.com/photo-1593313637552-29c2c0dacd35?w=400&h=500&fit=crop&auto=format" },
  { name: "Carl Hughes", role: "NICEIC Certified Electrician", img: "https://images.unsplash.com/photo-1516216628859-9bccecab13ca?w=400&h=500&fit=crop&auto=format" },
];

const TIMELINE = [
  { year: "2004", title: "Founded", desc: "Danny Mitchell started the company as a solo groundworks contractor serving local builders." },
  { year: "2008", title: "First Extension Team", desc: "Took on our first full extension project and built a dedicated team of in-house tradespeople." },
  { year: "2013", title: "NICEIC Certification", desc: "Achieved NICEIC approval, allowing us to carry out and certify all electrical work on our projects." },
  { year: "2018", title: "100th Extension", desc: "Completed our 100th full house extension — a milestone that marked our growth as a complete building contractor." },
  { year: "2024", title: "600+ Projects", desc: "Today we've completed over 600 projects with an unblemished reputation and zero complaints." },
];

export function About() {
  return (
    <div style={{ fontFamily: "'Barlow',sans-serif" }}>

      {/* Hero */}
      <section className="relative pt-40 pb-24" style={{ background: NAV }}>
        <div className="absolute top-0 left-0 bottom-0 w-1.5" style={{ background: ORANGE }} />
        <div
          className="absolute inset-0"
          style={{ backgroundImage: `url('https://images.unsplash.com/photo-1558227691-41ea78d1f631?w=1600&h=700&fit=crop&auto=format')`, backgroundSize: "cover", backgroundPosition: "center top", opacity: 0.12 }}
        />
        <div className="relative max-w-7xl mx-auto px-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-px w-10" style={{ background: ORANGE }} />
            <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "0.72rem", letterSpacing: "0.22em", textTransform: "uppercase", color: ORANGE }}>Our Story</span>
          </div>
          <h1 className="text-white leading-none uppercase mb-5" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "clamp(2.8rem,7vw,5rem)" }}>
            About Us
          </h1>
          <p className="max-w-xl" style={{ color: "rgba(255,255,255,0.55)", fontSize: "1rem", lineHeight: 1.7 }}>
            A family-run construction business built on reputation, quality, and a genuine passion for the trade.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="py-24 lg:py-32" style={{ background: "#fff" }}>
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1593786267440-550458cc882a?w=900&h=700&fit=crop&auto=format"
              alt="Mitchell Groundworks on site"
              className="w-full object-cover"
              style={{ height: 520 }}
            />
            <div className="absolute -bottom-6 -right-6 p-7" style={{ background: ORANGE }}>
              <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "2.5rem", color: "#fff", lineHeight: 1 }}>Est.</div>
              <div style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "2.5rem", color: "#fff", lineHeight: 1 }}>2004</div>
            </div>
          </div>

          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-10" style={{ background: ORANGE }} />
              <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "0.72rem", letterSpacing: "0.22em", textTransform: "uppercase", color: ORANGE }}>Who We Are</span>
            </div>
            <h2 className="leading-none uppercase mb-6" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "clamp(2rem,4vw,2.8rem)", color: NAV }}>
              Built on Reputation. Powered by the Trade.
            </h2>
            <p className="mb-4 leading-relaxed" style={{ color: "#52667F", fontSize: "0.95rem" }}>
              Mitchell Groundworks was founded in 2004 by Danny Mitchell with a single van, a digger, and a commitment to doing things properly. What started as a solo groundworks operation has grown into a full construction company employing a skilled in-house team covering every trade.
            </p>
            <p className="mb-4 leading-relaxed" style={{ color: "#52667F", fontSize: "0.95rem" }}>
              We specialise in complete house extensions — managing every element in-house from the initial dig to plastered walls, fitted kitchens, and certified electrical sign-off. Our clients deal with one team, one point of contact, and one standard of quality throughout.
            </p>
            <p className="mb-8 leading-relaxed" style={{ color: "#52667F", fontSize: "0.95rem" }}>
              Based in the South East, we work across Kent, Surrey, Sussex, and South London, with over 600 completed projects behind us and a reputation built entirely on word of mouth and repeat business.
            </p>
            <ul className="space-y-3">
              {["No sub-contractors — every trade is our own team","20+ years delivering residential & commercial projects","NICEIC certified electrical team","Fully insured — public liability & employer's liability"].map((i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle2 size={17} style={{ color: ORANGE, marginTop: 2, flexShrink: 0 }} />
                  <span style={{ color: "#3A4A5E", fontSize: "0.88rem" }}>{i}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 lg:py-28" style={{ background: "#F2F5FA" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-14 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-10" style={{ background: ORANGE }} />
              <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "0.72rem", letterSpacing: "0.22em", textTransform: "uppercase", color: ORANGE }}>Our Values</span>
              <div className="h-px w-10" style={{ background: ORANGE }} />
            </div>
            <h2 className="leading-none uppercase" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "clamp(2rem,4vw,2.8rem)", color: NAV }}>
              How We Work
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
            {VALUES.map((v) => (
              <div key={v.title} className="bg-white p-8" style={{ border: "1px solid rgba(11,28,54,0.07)" }}>
                <div className="w-12 h-12 flex items-center justify-center mb-5" style={{ background: ORANGE, color: "#fff" }}>
                  {v.icon}
                </div>
                <h3 className="uppercase mb-3" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "1.05rem", color: NAV }}>
                  {v.title}
                </h3>
                <p style={{ color: "#52667F", fontSize: "0.85rem", lineHeight: 1.65 }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24 lg:py-28" style={{ background: NAV }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-14">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-10" style={{ background: ORANGE }} />
              <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "0.72rem", letterSpacing: "0.22em", textTransform: "uppercase", color: ORANGE }}>Our History</span>
            </div>
            <h2 className="text-white leading-none uppercase" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "clamp(2rem,4vw,2.8rem)" }}>
              20 Years in the Making
            </h2>
          </div>
          <div className="relative">
            <div className="absolute left-[3.5rem] top-0 bottom-0 w-px hidden md:block" style={{ background: "rgba(255,255,255,0.1)" }} />
            <div className="space-y-8">
              {TIMELINE.map((t, i) => (
                <div key={t.year} className="flex gap-8 items-start">
                  <div className="w-28 shrink-0 text-right hidden md:block">
                    <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "1.4rem", color: ORANGE }}>{t.year}</span>
                  </div>
                  <div className="relative hidden md:flex items-start justify-center w-7 shrink-0 mt-1">
                    <div className="w-3 h-3 rounded-full z-10" style={{ background: ORANGE }} />
                  </div>
                  <div className="flex-1 pb-2">
                    <div className="md:hidden mb-1" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "1.1rem", color: ORANGE }}>{t.year}</div>
                    <h3 className="text-white uppercase mb-1" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "1.1rem" }}>
                      {t.title}
                    </h3>
                    <p style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.88rem", lineHeight: 1.65 }}>{t.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 lg:py-28" style={{ background: "#fff" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-14">
            <div className="flex items-center gap-3 mb-4">
              <div className="h-px w-10" style={{ background: ORANGE }} />
              <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "0.72rem", letterSpacing: "0.22em", textTransform: "uppercase", color: ORANGE }}>The Team</span>
            </div>
            <h2 className="leading-none uppercase" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "clamp(2rem,4vw,2.8rem)", color: NAV }}>
              Meet the People Behind the Work
            </h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {TEAM.map((m) => (
              <div key={m.name} className="group overflow-hidden" style={{ background: "#F2F5FA" }}>
                <div className="relative overflow-hidden" style={{ background: NAV }}>
                  <img
                    src={m.img}
                    alt={m.name}
                    className="w-full object-cover transition-transform duration-500 group-hover:scale-105 opacity-80"
                    style={{ height: 320 }}
                  />
                </div>
                <div className="p-6">
                  <h3 className="uppercase mb-1" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "1.2rem", color: NAV }}>{m.name}</h3>
                  <p style={{ color: ORANGE, fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 700, fontSize: "0.78rem", letterSpacing: "0.1em", textTransform: "uppercase" }}>{m.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20" style={{ background: ORANGE }}>
        <div className="max-w-7xl mx-auto px-6 flex flex-col lg:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="text-white leading-tight uppercase" style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "clamp(1.8rem,3.5vw,2.6rem)" }}>
              Let's Build Something Great Together
            </h2>
            <p style={{ color: "rgba(255,255,255,0.75)", fontSize: "0.9rem", marginTop: 4 }}>Free site visit and no-obligation quote. Respond within 24 hours.</p>
          </div>
          <Link
            to="/contact"
            className="flex items-center gap-2 px-8 py-4 shrink-0 text-[#F06A1A] transition-opacity hover:opacity-85"
            style={{ background: "#fff", fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "0.9rem", letterSpacing: "0.12em", textTransform: "uppercase" }}
          >
            Get in Touch <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
}
