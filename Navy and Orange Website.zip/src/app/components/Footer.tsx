import { Link } from "react-router";
import { Phone, Mail, MapPin, ArrowRight } from "lucide-react";

const ORANGE = "#F06A1A";

export function Footer() {
  return (
    <footer style={{ background: "#070F1E" }}>
      {/* Top strip */}
      <div style={{ background: ORANGE }}>
        <div className="max-w-7xl mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "1.3rem", color: "#fff", letterSpacing: "0.03em", textTransform: "uppercase" }}>
            Ready to start your project? Let's talk.
          </p>
          <Link
            to="/contact"
            className="flex items-center gap-2 px-6 py-3 shrink-0 transition-opacity hover:opacity-85"
            style={{ background: "#fff", fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 800, fontSize: "0.82rem", letterSpacing: "0.12em", textTransform: "uppercase", color: ORANGE }}
          >
            Get a Free Quote <ArrowRight size={15} />
          </Link>
        </div>
      </div>

      {/* Main */}
      <div className="max-w-7xl mx-auto px-6 pt-14 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 flex items-center justify-center shrink-0" style={{ background: ORANGE }}>
                <span style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, color: "#fff", fontSize: "1.1rem" }}>MG</span>
              </div>
              <div style={{ fontFamily: "'Barlow Condensed',sans-serif" }}>
                <div style={{ fontWeight: 900, color: "#fff", fontSize: "1rem", letterSpacing: "0.06em", textTransform: "uppercase" }}>Mitchell Groundworks</div>
                <div style={{ fontWeight: 700, color: ORANGE, fontSize: "0.65rem", letterSpacing: "0.14em", textTransform: "uppercase" }}>Ltd — Est. 2004</div>
              </div>
            </div>
            <p style={{ color: "rgba(255,255,255,0.4)", fontSize: "0.85rem", lineHeight: 1.7, fontFamily: "'Barlow',sans-serif" }}>
              Specialist groundworks and construction for residential and commercial clients across the South East.
            </p>
          </div>

          {/* Services */}
          <div>
            <h4 style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "0.75rem", letterSpacing: "0.18em", textTransform: "uppercase", color: ORANGE, marginBottom: "1.2rem" }}>Services</h4>
            <ul className="space-y-2.5">
              {["House Extensions","Groundworks & Drainage","Patios & Driveways","Plastering","Kitchen Fitting","Electrical Work","Loft Conversions","Retaining Walls"].map((s) => (
                <li key={s}>
                  <Link to="/services" style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.84rem", fontFamily: "'Barlow',sans-serif" }} className="hover:text-white transition-colors">{s}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "0.75rem", letterSpacing: "0.18em", textTransform: "uppercase", color: ORANGE, marginBottom: "1.2rem" }}>Company</h4>
            <ul className="space-y-2.5">
              {[{ to: "/about", l: "About Us" },{ to: "/projects", l: "Projects" },{ to: "/blog", l: "Blog" },{ to: "/contact", l: "Contact" }].map((x) => (
                <li key={x.to}>
                  <Link to={x.to} style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.84rem", fontFamily: "'Barlow',sans-serif" }} className="hover:text-white transition-colors">{x.l}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 style={{ fontFamily: "'Barlow Condensed',sans-serif", fontWeight: 900, fontSize: "0.75rem", letterSpacing: "0.18em", textTransform: "uppercase", color: ORANGE, marginBottom: "1.2rem" }}>Contact</h4>
            <ul className="space-y-4">
              <li className="flex gap-3">
                <Phone size={15} style={{ color: ORANGE, marginTop: 2, flexShrink: 0 }} />
                <div>
                  <div style={{ color: "#fff", fontSize: "0.9rem", fontFamily: "'Barlow',sans-serif", fontWeight: 600 }}>07700 000 000</div>
                  <div style={{ color: "rgba(255,255,255,0.35)", fontSize: "0.75rem", fontFamily: "'Barlow',sans-serif" }}>Mon–Fri 7am–6pm</div>
                </div>
              </li>
              <li className="flex gap-3">
                <Mail size={15} style={{ color: ORANGE, marginTop: 2, flexShrink: 0 }} />
                <span style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.84rem", fontFamily: "'Barlow',sans-serif" }}>info@mitchellgw.co.uk</span>
              </li>
              <li className="flex gap-3">
                <MapPin size={15} style={{ color: ORANGE, marginTop: 2, flexShrink: 0 }} />
                <span style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.84rem", fontFamily: "'Barlow',sans-serif" }}>South East England</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t pt-6 flex flex-col sm:flex-row justify-between gap-2" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
          <p style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.78rem", fontFamily: "'Barlow',sans-serif" }}>© 2024 Mitchell Groundworks Ltd. Company No. 12345678. Registered in England & Wales.</p>
          <p style={{ color: "rgba(255,255,255,0.18)", fontSize: "0.78rem", fontFamily: "'Barlow',sans-serif" }}>All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
